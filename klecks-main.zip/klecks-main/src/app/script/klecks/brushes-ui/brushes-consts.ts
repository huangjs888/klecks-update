
export const eventResMs = 20;