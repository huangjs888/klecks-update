import {BB} from '../../../bb/bb';
// @ts-ignore
import rotateImg from 'url:~/src/app/img/ui/cursor-rotate.png';
import {KeyListener} from '../../../bb/input/key-listener';
import {IVector2D} from '../../../bb/bb.types';

export interface ITransform {
    x: number; // center of transform region. image space
    y: number;
    width: number; // size of transform region. image space
    height: number;
    angleDeg: number; // angle of transform region. degrees
}


/**
 * snap entire transform to pixel grid. changes transform
 *
 * for x y:
 * If a dimension has an even size, it be an integer.
 * If it's uneven, it's sits exactly half way between two pixels.
 *
 * @param transform
 */
function snapToPixel(transform: ITransform): void {
    if (Math.abs(transform.angleDeg) % 90 !== 0) {
        return;
    }

    transform.width = Math.round(transform.width);
    transform.height = Math.round(transform.height);
    // 0° is original orientation.
    // At 90° and 270° width and height become swapped due to different orientation.
    const whSwapped = Math.abs(transform.angleDeg - 90) % 180 === 0;
    transform.x = ((whSwapped ? transform.height : transform.width) % 2 === 0) ? Math.round(transform.x) : Math.round(transform.x - 0.5) + 0.5;
    transform.y = ((whSwapped ? transform.width : transform.height) % 2 === 0)  ? Math.round(transform.y) : Math.round(transform.y - 0.5) + 0.5;
}

function copyTransform(transform: ITransform): ITransform {
    return {
        x: transform.x,
        y: transform.y,
        width: transform.width,
        height: transform.height,
        angleDeg: transform.angleDeg,
    };
}

/**
 * image space to transform space
 * - origin of transform space is at center of transform bounds.
 * - same scale as image space. -> one unit is x: 1/width, y: 1/height
 * - up is where transform points up
 * - x goes right
 * - y goes down
 * @param x
 * @param y
 * @param transform
 */
function toTransformSpace (x: number, y: number, transform: ITransform): IVector2D {
    let px, py;
    px = x - transform.x;
    py = y - transform.y;

    const rot = BB.rotateAround({x: 0, y: 0},
        {x: px, y: py},
        -transform.angleDeg);
    px = rot.x;
    py = rot.y;

    return {
        x: px,
        y: py,
    };
}

/**
 * transform space to image space
 * @param x
 * @param y
 * @param transform
 */
function toImageSpace(x: number, y: number, transform: ITransform): IVector2D {
    const rot = BB.rotateAround({x: 0, y: 0},
        {x: x, y: y},
        transform.angleDeg);
    return {
        x: rot.x + transform.x,
        y: rot.y + transform.y,
    };
}



/**
 * Free Transform UI
 * rotate, scale, translate
 *
 * - if rotation is multiple of 90° it will snap to pixels, to be more useful for pixel art
 * - when rotation goes from non-multiple of 90° to a multiple, it will snap position and width height to pixels
 * - transform.x, transform.y can sit between pixels (by 0.5) if width or height is odd number.
 *      - this is what complicates things
 * - if transform region small, corner grips move out of the way
 *
 * iX iY, iP.x, iP.y - i indicates image space
 * tX tY, tP.x, tP.y - t indicates transform space
 *
 * Not sure if can be used for navigable canvas. (especially if canvas rotates view)
 * Probably can't be extended for distort. Needs a different approach.
 *
 * --- DOM structure ---
 * rootEl {
 * 	transEl [
 * 		boundsEl
 * 		edges[]
 * 		corners[] - round grips in the corner of transform region
 * 		angleGrip
 * 	]
 * }
 *
 */
export class FreeTransform {

    // --- private ---
    private readonly transform: ITransform; // coordinates and dimensions of transformation
    private isConstrained: boolean;
    private ratio: number; // aspect ratio of transform
    private readonly scale: number;
    private readonly scaled = { // scaled coordinates and dimensions for screenspace
        x: 0,
        y: 0,
        width: 0,
        height: 0,
        corners: [{x: 0, y: 0}], // in transform space
    };
    private readonly minSnapDist = 7; // minimal snapping distance in px screenspace
    private snappingEnabled: boolean;
    private readonly snapX: number[];
    private readonly snapY: number[];
    private readonly callback: (transform: ITransform) => void;


    private readonly cornerCursors = ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'];
    private readonly gripSize = 14;
    private readonly edgeSize = 10;

    private readonly rootEl: HTMLElement; // sits at origin of image
    private readonly transEl: HTMLElement; // at middle of transform. rotates
    private readonly boundsEl: HTMLElement; // draggable bounds rectangle with outline
    private readonly corners: {
        i: number; // index in corners array
        el: HTMLElement; // draggable corner circle in DOM
        x: number; // unscaled position (transform space)
        y: number;
        virtualPos: IVector2D; // unscaled temporary position (image space)
        updateDOM: () => void; // update styling in DOM
        pointerListener: any;
    }[] = [];
    private keyListener: KeyListener;
    private boundsPointerListener: any; // BB.PointerListener
    private anglePointerListener: any; // BB.PointerListener
    private readonly edges: { // derive position from corners
        el: HTMLElement;
        updateDOM: () => void;
        pointerListener: any;
    }[] = [];
    private readonly angleGrip: {
        el: HTMLElement,
        x: number; // transform space
        y: number;
        snap: boolean,
        updateDOM: () => void,
    };

    private updateScaled(): void {
        this.scaled.x = this.transform.x * this.scale;
        this.scaled.y = this.transform.y * this.scale;
        this.scaled.width = this.transform.width * this.scale;
        this.scaled.height = this.transform.height * this.scale;
        this.scaled.corners = this.corners.map((item) => {
            return {x: item.x * this.scale, y: item.y * this.scale};
        });
    }

    /**
     * Returns snapped point, if ix, iy snaps. If no snapping, returns point unchanged.
     * both in image space
     *
     * @param iX - image space
     * @param iY - image space
     * @private
     */
    private snapCorner (iX: number, iY: number): IVector2D {
        if (!this.snappingEnabled) {
            return {x: iX, y: iY};
        }
        let dist: number;
        const snap: {
            x: number;
            y: number;
            dist: {
                x: number;
                y: number;
            }
        } = {
            x: null,
            y: null,
            dist: {
                x: null,
                y: null,
            }
        };
        for (let e = 0; e < this.snapX.length; e++) {
            dist = Math.abs(iX - this.snapX[e]);
            if (dist < this.minSnapDist / this.scale) {
                if (snap.x === null || dist < snap.dist.x) {
                    snap.x = this.snapX[e];
                    snap.dist.x = dist;
                }
            }
        }
        for (let e = 0; e < this.snapY.length; e++) {
            dist = Math.abs(iY - this.snapY[e]);
            if (dist < this.minSnapDist / this.scale) {
                if (snap.y === null || dist < snap.dist.y) {
                    snap.y = this.snapY[e];
                    snap.dist.y = dist;
                }
            }
        }

        if (snap.x === null && snap.y === null) {
            return {
                x: iX,
                y: iY,
            };
        }
        return {
            x: snap.x ?? iX,
            y: snap.y ?? iY,
        };
    }

    /**
     * If constrained return nearest corner pos that fits aspect ratio
     *
     * @param cornerIndex
     * @param iX
     * @param iY
     * @private
     */
    private constrainCorner (cornerIndex: number, iX: number, iY: number): IVector2D {
        if (!this.isConstrained) {
            return {
                x: iX,
                y: iY,
            };
        }
        const flip = this.transform.width * this.transform.height < 0 ? -1 : 1;
        return BB.projectPointOnLine(
            {x: this.transform.x, y: this.transform.y},
            toImageSpace(this.ratio, flip * ([0, 2].includes(cornerIndex) ? 1 : -1), this.transform),
            {x: iX, y: iY}
        );
    }

    /**
     * Update corners according to width height.
     * Not their DOM.
     */
    private updateCornerPositions (): void {
        this.corners[0].x = (-this.transform.width / 2); // top left
        this.corners[0].y = (-this.transform.height / 2);

        this.corners[1].x = (this.transform.width / 2); // top right
        this.corners[1].y = (-this.transform.height / 2);

        this.corners[2].x = (this.transform.width / 2); // bottom right
        this.corners[2].y = (this.transform.height / 2);

        this.corners[3].x = (-this.transform.width / 2); // bottom left
        this.corners[3].y = (this.transform.height / 2);
    }

    /**
     * If constrained and dragging an edge, restore aspect ratio
     * Updates corner positions.
     *
     * @param widthChanged
     * @param heightChanged
     * @private
     */
    private restoreRatio (widthChanged: boolean, heightChanged: boolean): void {
        if (!this.isConstrained) {
            return;
        }
        const angle90 = Math.abs(this.transform.angleDeg) % 90 === 0;
        const whSwapped = Math.abs(this.transform.angleDeg - 90) % 180 === 0;
        if (heightChanged && !widthChanged) {
            const newHeight = Math.abs(this.corners[3].y - this.corners[0].y);
            let newWidth = this.ratio * newHeight;
            if (angle90) {
                newWidth = (whSwapped ? this.transform.y % 1 : this.transform.x % 1) === 0 ?
                    BB.roundEven(newWidth) : BB.roundUneven(newWidth);
            }
            if (this.corners[1].x - this.corners[0].x < 0) {
                newWidth *= -1;
            }
            this.corners[0].x = -newWidth / 2;
            this.corners[3].x = -newWidth / 2;
            this.corners[1].x = newWidth / 2;
            this.corners[2].x = newWidth / 2;
        }
        if (!heightChanged && widthChanged) {
            const newWidth = Math.abs(this.corners[0].x - this.corners[1].x);
            let newHeight = newWidth / this.ratio;
            if (angle90) {
                newHeight = (whSwapped ? this.transform.x % 1 : this.transform.y % 1) === 0  ?
                    BB.roundEven(newHeight) : BB.roundUneven(newHeight);
            }
            if (this.corners[3].y - this.corners[0].y < 0) {
                newHeight *= -1;
            }
            this.corners[0].y = -newHeight / 2;
            this.corners[1].y = -newHeight / 2;
            this.corners[2].y = newHeight / 2;
            this.corners[3].y = newHeight / 2;
        }
    }


    /**
     * update transform based on corners
     * @private
     */
    private updateTransformViaCorners (): void {

        // calc transform center in image space
        const rot = BB.rotateAround(
            {x: 0, y: 0},
            {
                x: (this.corners[0].x + this.corners[1].x) / 2,
                y: (this.corners[0].y + this.corners[3].y) / 2,
            },
            this.transform.angleDeg
        );
        this.transform.x = rot.x + this.transform.x;
        this.transform.y = rot.y + this.transform.y;

        // update size
        this.transform.width = this.corners[1].x - this.corners[0].x;
        this.transform.height = this.corners[3].y - this.corners[0].y;

        // new center means corners changed their position
        this.updateCornerPositions();

        this.updateDOM();
    }

    /**
     * updates DOM according to transform
     * @param skipCallback
     */
    private updateDOM (skipCallback?: boolean) {
        this.updateScaled();

        BB.css(this.transEl, {
            left: this.scaled.x + "px",
            top: this.scaled.y + "px",
            transformOrigin: "0 0",
            transform: "rotate(" + this.transform.angleDeg + "deg)",
        });

        BB.css(this.boundsEl, {
            width: Math.abs(this.scaled.width) + "px",
            height: Math.abs(this.scaled.height) + "px",
            left: Math.min(this.scaled.corners[0].x, this.scaled.corners[1].x) + "px",
            top: Math.min(this.scaled.corners[0].y, this.scaled.corners[3].y) + "px"
        });

        this.corners[0].updateDOM();
        this.corners[1].updateDOM();
        this.corners[2].updateDOM();
        this.corners[3].updateDOM();

        this.edges[0].updateDOM();
        this.edges[1].updateDOM();
        this.edges[2].updateDOM();
        this.edges[3].updateDOM();


        this.angleGrip.x = 0;
        this.angleGrip.y = (-Math.abs(this.transform.height * this.scale) / 2) - 20;
        this.angleGrip.updateDOM();
        if (!skipCallback) {
            if (this.callback) { // why should updateDOM trigger the callback?
                this.callback(copyTransform(this.transform));
            }
        }
    }



    // --- public ---
    constructor (
        params: {
            x: number; // center of transform region. image space
            y: number;
            width: number; // size of transform region. image space
            height: number;
            angleDeg: number; // angle of transform region. degrees

            isConstrained: boolean; // proportions constrained
            snapX: number[]; // where snapping along X axis. image space
            snapY: number[]; // where snapping along X axis. image space
            scale: number; // ratio of screen-space / image-space
            callback: (transform: ITransform) => void;
        }
    ) {
        this.transform = { // coordinates and dimensions of transformation
            x: params.x,
            y: params.y,
            width: params.width,
            height: params.height,
            angleDeg: params.angleDeg,
        };

        this.isConstrained = !!params.isConstrained;

        this.snapX = params.snapX;
        this.snapY = params.snapY;
        this.callback = params.callback;
        this.scale = params.scale;
        this.snappingEnabled = true;
        this.ratio = this.transform.width / this.transform.height;

        this.rootEl = BB.el({
            className: 'kl-free-transform',
            css: {
                userSelect: 'none',
            }
        });
        this.transEl = BB.el({
            parent: this.rootEl,
            css: {
                position: 'absolute',
            }
        });

        this.boundsEl = BB.el({
            css: {
                position: 'absolute',
                cursor: 'move',
                boxShadow: 'rgba(255, 255, 255, 0.5) 0 0 0 1px inset, rgba(0, 0, 0, 0.5) 0 0 0 1px',
            }
        });

        const pointerRemainder = {
            x: 0,
            y: 0,
        };
        function resetRemainder() {
            pointerRemainder.x = 0;
            pointerRemainder.y = 0;
        }
        this.keyListener = new BB.KeyListener({});

        let boundsStartP = {
            x: 0,
            y: 0,
        }
        this.boundsPointerListener = new BB.PointerListener({
            target: this.boundsEl,
            fixScribble: true,
            onPointer: (event) => {
                event.eventPreventDefault();
                if (event.type === 'pointerdown') {
                    boundsStartP = {x: this.transform.x, y: this.transform.y};
                }
                if (event.type === 'pointermove' && event.button === 'left') {
                    this.transform.x = boundsStartP.x + (event.pageX - event.downPageX) / this.scale;
                    this.transform.y = boundsStartP.y + (event.pageY - event.downPageY) / this.scale;


                    let dist;
                    let snap: any = {};
                    if (this.snappingEnabled) {
                        let i;
                        for (i = 0; i < this.snapX.length; i++) {
                            dist = Math.abs(this.transform.x - this.snapX[i]);
                            if (dist < this.minSnapDist / this.scale) {
                                if (!snap.x || dist < snap.distX) {
                                    snap.x = this.snapX[i];
                                    snap.distX = dist;
                                }
                            }
                        }
                        for (i = 0; i < this.snapY.length; i++) {
                            dist = Math.abs(this.transform.y - this.snapY[i]);
                            if (dist < this.minSnapDist / this.scale) {
                                if (!snap.y || dist < snap.distY) {
                                    snap.y = this.snapY[i];
                                    snap.distY = dist;
                                }
                            }
                        }

                        let iP;
                        for (i = 0; i < 4; i++) {
                            iP = toImageSpace(this.corners[i].x, this.corners[i].y, this.transform);
                            let j;
                            for (j = 0; j < this.snapX.length; j++) {
                                dist = Math.abs(iP.x - this.snapX[j]);
                                if (dist < this.minSnapDist / this.scale) {
                                    if (!snap.x || dist < snap.distX) {
                                        snap.x = this.snapX[j] - (iP.x - this.transform.x);
                                        snap.distX = dist;
                                    }
                                }
                            }
                            for (j = 0; j < this.snapY.length; j++) {
                                dist = Math.abs(iP.y - this.snapY[j]);
                                if (dist < this.minSnapDist / this.scale) {
                                    if (!snap.y || dist < snap.distY) {
                                        snap.y = this.snapY[j] - (iP.y - this.transform.y);
                                        snap.distY = dist;
                                    }
                                }
                            }
                        }
                    }
                    if (this.keyListener.getComboStr() === 'shift') {
                        let projected = BB.projectPointOnLine(
                            {x: 0, y: boundsStartP.y},
                            {x: 10, y: boundsStartP.y},
                            {x: this.transform.x, y: this.transform.y});
                        let dist = BB.dist(projected.x, projected.y, this.transform.x, this.transform.y);
                        snap = {};
                        snap.x = projected.x;
                        snap.y = projected.y;
                        snap.distX = dist;
                        snap.distY = dist;

                        projected = BB.projectPointOnLine(
                            {x: boundsStartP.x, y: 0},
                            {x: boundsStartP.x, y: 10},
                            {x: this.transform.x, y: this.transform.y});
                        dist = BB.dist(projected.x, projected.y, this.transform.x, this.transform.y);
                        if (dist < snap.distX) {
                            snap.x = projected.x;
                            snap.y = projected.y;
                            snap.distX = dist;
                            snap.distY = dist;
                        }

                        projected = BB.projectPointOnLine(
                            {x: boundsStartP.x, y: boundsStartP.y},
                            {x: boundsStartP.x + 1, y: boundsStartP.y + 1},
                            {x: this.transform.x, y: this.transform.y});
                        dist = BB.dist(projected.x, projected.y, this.transform.x, this.transform.y);
                        if (dist < snap.distX) {
                            snap.x = projected.x;
                            snap.y = projected.y;
                            snap.distX = dist;
                            snap.distY = dist;
                        }

                        projected = BB.projectPointOnLine(
                            {x: boundsStartP.x, y: boundsStartP.y},
                            {x: boundsStartP.x + 1, y: boundsStartP.y - 1},
                            {x: this.transform.x, y: this.transform.y});
                        dist = BB.dist(projected.x, projected.y, this.transform.x, this.transform.y);
                        if (dist < snap.distX) {
                            snap.x = projected.x;
                            snap.y = projected.y;
                            snap.distX = dist;
                            snap.distY = dist;
                        }
                    }
                    if (snap.x != undefined) {
                        this.transform.x = snap.x;
                    }
                    if (snap.y != undefined) {
                        this.transform.y = snap.y;
                    }

                    // snap to pixels
                    if (Math.abs(this.transform.angleDeg) % 90 === 0) {
                        snapToPixel(this.transform);
                        this.updateCornerPositions();
                    }

                    this.updateDOM();
                }
            }
        })

        for (let i = 0; i < 4; i++) {
            ((i) => {
                const g = this.corners[i] = {
                    i: i,
                    el: BB.el({
                        css: {
                            width: this.gripSize + 'px',
                            height: this.gripSize + 'px',
                            background: '#fff',
                            /*background: [
                                '#ff0000',
                                '#00ff00',
                                '#0000ff',
                                '#ff00ff',
                            ][i],*/
                            borderRadius: this.gripSize + 'px',
                            position: 'absolute',
                            boxShadow: 'inset 0 0 0 2px #000'
                        }
                    }),
                    x: 0,
                    y: 0,
                    virtualPos: {
                        x: 0,
                        y: 0,
                    },
                    updateDOM: null,
                    pointerListener: null,
                };
                g.updateDOM = () => {

                    // grip position
                    // if gets small, offset grips, so easier to handle
                    const offsetArr = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(item => {
                        item[0] *= this.transform.width > 0 ? 1 : -1;
                        item[1] *= this.transform.height > 0 ? 1 : -1;
                        return item;
                    });
                    const tinyOffset = Math.abs(this.scaled.width) < 20 || Math.abs(this.scaled.height) < 20 ? 10 : 0;

                    BB.css(g.el, {
                        left: (this.scaled.corners[g.i].x - this.gripSize / 2 + offsetArr[i][0] * tinyOffset) + 'px',
                        top: (this.scaled.corners[g.i].y - this.gripSize / 2 + offsetArr[i][1] * tinyOffset) + 'px'
                    });


                    // cursor
                    let angle = BB.pointsToAngleDeg(
                        {
                            x: this.transform.x,
                            y: this.transform.y,
                        },
                        toImageSpace(g.x, g.y, this.transform),
                    ) + 135; // offset so nw is 0
                    while (angle < 0) {
                        angle += 360;
                    }
                    let index = Math.round(angle / 45) % this.cornerCursors.length;
                    BB.css(g.el, {
                        cursor: this.cornerCursors[index] + '-resize',
                    });
                };

                g.pointerListener = new BB.PointerListener({
                    target: this.corners[i].el,
                    fixScribble: true,
                    onPointer: (event) => {
                        event.eventPreventDefault();
                        if (event.type === 'pointerdown' && event.button === 'left') {
                            this.corners[i].virtualPos = toImageSpace(this.corners[i].x, this.corners[i].y, this.transform);

                        } else if (event.type === 'pointermove' && event.button === 'left') {
                            this.corners[i].virtualPos.x += event.dX / this.scale;
                            this.corners[i].virtualPos.y += event.dY / this.scale;

                            let iP = {
                                x: this.corners[i].virtualPos.x,
                                y: this.corners[i].virtualPos.y,
                            };
                            iP = this.constrainCorner(i, iP.x, iP.y);
                            if (!this.isConstrained) {
                                iP = this.snapCorner(iP.x, iP.y);
                            }

                            if (Math.abs(this.transform.angleDeg) % 90 === 0) {
                                iP.x = Math.round(iP.x);
                                iP.y = Math.round(iP.y);
                            }

                            const tP = toTransformSpace(iP.x, iP.y, this.transform);

                            const dX = tP.x - this.corners[i].x;
                            const dY = tP.y - this.corners[i].y;
                            this.corners[i].x = tP.x;
                            this.corners[i].y = tP.y;

                            let indexes = [];
                            if (i === 0) { // top left
                                indexes = [3, 1, 2];
                            } else if (i === 1) { // top right
                                indexes = [2, 0, 3];
                            } else if (i === 2) { // bottom right
                                indexes = [1, 3, 0];
                            } else if (i === 3) { // bottom left
                                indexes = [0, 2, 1];
                            }

                            this.corners[indexes[0]].x = this.corners[i].x;
                            this.corners[indexes[1]].y = this.corners[i].y;
                            if (this.keyListener.isPressed('shift')) {
                                this.corners[indexes[2]].x -= dX;
                                this.corners[indexes[2]].y -= dY;
                                this.corners[indexes[1]].x = this.corners[indexes[2]].x;
                                this.corners[indexes[0]].y = this.corners[indexes[2]].y;
                            }

                            this.updateTransformViaCorners();

                        }
                    }
                });

            })(i);
        }

        this.updateCornerPositions();
        this.updateScaled();

        let isInverted: boolean;
        for (let i = 0; i < 4; i++) {
            ((i) => {
                this.edges[i] = {
                    el: BB.el({
                        css: {
                            width: this.edgeSize + 'px',
                            height: this.edgeSize + 'px',
                            /*background: [
                                '#ff000044',
                                '#00ff0044',
                                '#0000ff44',
                                '#ff00ff44',
                            ][i],*/
                            position: 'absolute',
                        },
                    }),
                    updateDOM: null,
                    pointerListener: null,
                };
                const g = this.edges[i];
                g.updateDOM = () => {
                    if (i === 0) {
                        BB.css(g.el, {
                            left: Math.min(this.scaled.corners[0].x, this.scaled.corners[1].x) + 'px',
                            top: (Math.min(this.scaled.corners[0].y, this.scaled.corners[3].y) - this.edgeSize) + 'px',
                            width: Math.abs(this.scaled.width) + 'px',
                            height: this.edgeSize + 'px',
                        });
                    } else if (i === 1) {
                        BB.css(g.el, {
                            left: Math.max(this.scaled.corners[0].x, this.scaled.corners[1].x) + 'px',
                            top: Math.min(this.scaled.corners[1].y, this.scaled.corners[2].y) + 'px',
                            width: this.edgeSize + 'px',
                            height: Math.abs(this.scaled.height) + 'px',
                        });
                    } else if (i === 2) {
                        BB.css(g.el, {
                            left: Math.min(this.scaled.corners[3].x, this.scaled.corners[2].x) + 'px',
                            top: Math.max(this.scaled.corners[0].y,this.scaled.corners[3].y) + 'px',
                            width: Math.abs(this.scaled.width) + 'px',
                            height: this.edgeSize + 'px',
                        });
                    } else if (i === 3) {
                        BB.css(g.el, {
                            left: (Math.min(this.scaled.corners[0].x, this.scaled.corners[1].x) - this.edgeSize) + 'px',
                            top: Math.min(this.scaled.corners[0].y, this.scaled.corners[3].y) + 'px',
                            width: this.edgeSize + 'px',
                            height: Math.abs(this.scaled.height) + 'px',
                        });
                    }
                    let angleOffset = Math.round(this.transform.angleDeg / 45);
                    while (angleOffset < 0)
                        angleOffset += 8;
                    angleOffset = (i * 2 + 1 + angleOffset) % this.cornerCursors.length;
                    g.el.style.cursor = this.cornerCursors[angleOffset] + '-resize';

                };

                const isVertical = [0, 2].includes(i);
                g.pointerListener = new BB.PointerListener({
                    target: this.edges[i].el,
                    fixScribble: true,
                    onPointer: (event) => {
                        event.eventPreventDefault();
                        if (event.type === 'pointerdown' && event.button === 'left') {
                            if (isVertical) { // top bottom
                                isInverted = this.corners[0].y >= this.corners[3].y;
                            } else { // left right
                                isInverted = this.corners[0].x >= this.corners[1].x;
                            }
                            resetRemainder();
                        }
                        if (event.type === 'pointermove' && event.button === 'left') {
                            const tfD = BB.rotateAround({x: 0, y: 0},
                                {x: event.dX / this.scale, y: event.dY / this.scale},
                                -this.transform.angleDeg);
                            let ti = {
                                dX: tfD.x,
                                dY: tfD.y,
                            };
                            if (Math.abs(this.transform.angleDeg) % 90 === 0) {
                                ti = BB.intDxy(pointerRemainder, tfD.x, tfD.y);
                            }

                            let indexes = [];
                            if (i === 0) { // top
                                indexes = [2, 3, 0, 1];
                            } else if (i === 1) { // right
                                indexes = [0, 3, 1, 2];
                            } else if (i === 2) { // bottom
                                indexes = [0, 1, 2, 3];
                            } else if (i === 3) { // left
                                indexes = [1, 2, 0, 3];
                            }

                            let dimension = isVertical ? 'y' : 'x';
                            let d = isVertical ? ti.dY : ti.dX;

                            if (isInverted) {
                                this.corners[indexes[0]][dimension] += d;
                                this.corners[indexes[1]][dimension] += d;
                            } else {
                                this.corners[indexes[2]][dimension] += d;
                                this.corners[indexes[3]][dimension] += d;
                            }
                            if (this.keyListener.isPressed('shift')) {
                                if (isInverted) {
                                    this.corners[indexes[2]][dimension] -= d;
                                    this.corners[indexes[3]][dimension] -= d;
                                } else {
                                    this.corners[indexes[0]][dimension] -= d;
                                    this.corners[indexes[1]][dimension] -= d;
                                }
                            }

                            if (isVertical) { // top bottom
                                this.restoreRatio(false, true);
                            } else { // left right
                                this.restoreRatio(true, false);
                            }

                            this.updateTransformViaCorners();

                        }
                    }
                });

            })(i);
        }

        this.angleGrip = {
            el: BB.el({
                css: {
                    cursor: 'url(' + rotateImg + ') 10 10, move',
                    width: this.gripSize + 'px',
                    height: this.gripSize + 'px',
                    background: '#0ff',
                    borderRadius: this.gripSize + 'px',
                    position: 'absolute',
                    boxShadow: 'inset 0 0 0 2px #000',
                },
            }),
            x: 0,
            y: 0,
            snap: false,
            updateDOM: () => {
                BB.css(this.angleGrip.el, {
                    left: (this.angleGrip.x - this.gripSize / 2) + 'px',
                    top: (this.angleGrip.y - this.gripSize / 2) + 'px',
                });
            },
        };
        BB.el({
            parent: this.angleGrip.el,
            css: {
                width: '2px',
                height: '13px',
                left: (this.gripSize / 2 - 1) + 'px',
                top: this.gripSize + 'px',
                background: '#0ff',
                position: 'absolute'
            }
        });

        this.anglePointerListener = new BB.PointerListener({
            target: this.angleGrip.el,
            fixScribble: true,
            onPointer: (event) => {
                event.eventPreventDefault();
                if (event.type === 'pointermove' && event.button === 'left') {

                    const bounds = this.rootEl.getBoundingClientRect();
                    const offset = {
                        x: bounds.left - this.rootEl.scrollLeft,
                        y: bounds.top - this.rootEl.scrollTop,
                    };
                    const iP = {x: (event.clientX - offset.x) / this.scale, y: (event.clientY - offset.y) / this.scale};

                    const a = BB.pointsToAngleDeg({x: this.transform.x, y: this.transform.y}, iP) + 90;
                    this.transform.angleDeg = a;
                    const snapDeg = Math.round(a / 360 * 8) * 45;
                    if (this.keyListener.getComboStr() === 'shift') {
                        this.transform.angleDeg = snapDeg;
                    } else if (this.snappingEnabled && Math.abs(snapDeg - a) < 8) {
                        this.transform.angleDeg = snapDeg;
                    }
                    this.updateDOM();

                }
                if (event.type === 'pointerup') {
                    if (Math.abs(this.transform.angleDeg) % 90 === 0) {
                        snapToPixel(this.transform);
                        this.updateCornerPositions();
                        this.updateDOM();
                    }
                }
            }
        });

        snapToPixel(this.transform);
        this.updateDOM(true);
        BB.append(this.transEl, [
            this.boundsEl,
            this.edges[0].el,
            this.edges[1].el,
            this.edges[2].el,
            this.edges[3].el,
            this.corners[0].el,
            this.corners[1].el,
            this.corners[2].el,
            this.corners[3].el,
            this.angleGrip.el,
        ]);


    }



    getTransform (): ITransform {
        return copyTransform(this.transform);
    }

    setConstrained (b: boolean): void {
        this.isConstrained = !!b;
        if (b && this.transform.width !== 0 && this.transform.height !== 0) {
            this.ratio = Math.abs(this.transform.width / this.transform.height);
        }
    }

    setSnapping (s: boolean): void {
        this.snappingEnabled = !!s;
    }

    setPos (p: IVector2D): void {
        this.transform.x = p.x;
        this.transform.y = p.y;
        this.updateDOM(true);
    }

    move (dX: number, dY: number): void {
        this.transform.x += dX;
        this.transform.y += dY;
        this.updateDOM(false);
    }

    setSize (w: number, h: number): void {
        this.transform.width = w;
        this.transform.height = h;
        if (Math.abs(this.transform.angleDeg) % 90 === 0) {
            snapToPixel(this.transform);
        }
        this.updateCornerPositions();
        this.updateDOM(false);
    }

    setAngleDeg (a: number): void {
        this.transform.angleDeg = a;
        if (Math.abs(this.transform.angleDeg) % 90 === 0) {
            snapToPixel(this.transform);
            this.updateCornerPositions();
        }
        this.updateDOM(true);
    }

    getElement (): HTMLElement {
        return this.rootEl;
    }

    getRatio (): number {
        return this.ratio;
    }

    destroy (): void {
        this.keyListener.destroy();
        this.boundsPointerListener.destroy();
        this.corners[0].pointerListener.destroy();
        this.corners[1].pointerListener.destroy();
        this.corners[2].pointerListener.destroy();
        this.corners[3].pointerListener.destroy();
        this.edges[0].pointerListener.destroy();
        this.edges[1].pointerListener.destroy();
        this.edges[2].pointerListener.destroy();
        this.edges[3].pointerListener.destroy();
        this.anglePointerListener.destroy();
    }

}
