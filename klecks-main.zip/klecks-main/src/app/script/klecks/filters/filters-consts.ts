
export const eventResMs = 60;